#include<iostream>
using namespace std;
int main()
 {
	int t;
	cin>>t;
	while(t--)
	{
	    int n,time,pass;
	    cin>>n>>time>>pass;
	    int a[n];
	    int b[n];
	    for(int i=0;i<n;++i){
	        cin>>a[i];
	        cin>>b[i];
	    }
	    int dp[n+1][time+1];
	    for(int i=0;i<=n;++i)
	    {
	        for(int j=0;j<=time;++j){
	            dp[i][j]=0;
	        }
	    }
	    
	    for(int i=1;i<=n;++i){
	        for(int j=1;j<=time;++j){
	            
	            if(j<a[i-1]){
	                dp[i][j]=dp[i-1][j];
	               
	            }
	            else if(j>=a[i-1]){
	                dp[i][j]=max(dp[i-1][j],b[i-1]+dp[i-1][j-a[i-1]]);
	            }
	            
	        }
	        
	    }
	 
        int max1=dp[n][time];
        int total=0;
        int i=n,j=time;
        while(i&&j){
	        if(dp[i][j]==dp[i-1][j]){
	            i=i-1;
	        }
	        else {
	            total+=a[i-1];
	            j=j-a[i-1];
	            i=i-1;
	        }
	    }
	    if(max1>=pass) {
	        cout<<"YES "<<total<<endl;
	    } else{
            cout<<"NO"<<endl;
        }
	}
	return 0;
}
#include<iostream>
using namespace std;

int main() {
    int T;
    cin>>T;
    while(T--)
    {
        int n;
        cin>>n;
        int arr[n][3];
        
        int i=0;
        while(i<n){
            cin>>arr[i][0]>>arr[i][1]>>arr[i][2];
            i++;
        }
        int s[n][3];
        for( i=0;i<3;i++){
            s[0][i]=arr[0][i];
        }
        for(i=1;i<n;i++)
        {
            s[i][0]=min(s[i-1][1],s[i-1][2])+arr[i][0];
            s[i][1]=min(s[i-1][0],s[i-1][2])+arr[i][1];
            s[i][2]=min(s[i-1][0],s[i-1][1])+arr[i][2];
        }
        int m=min(s[n-1][0],s[n-1][1]);
        if(s[n-1][2]<m)
            cout<<s[n-1][2]<<endl;
        else
            cout<<m<<endl;
    }

	return 0;
}
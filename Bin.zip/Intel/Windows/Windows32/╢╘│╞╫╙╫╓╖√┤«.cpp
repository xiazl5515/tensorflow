#include<iostream>
using namespace std;
int fn(string str,int len)
{
    int ans=0;
    for(int i=0;i<=len;i++)
    {
        int lsum=0,rsum=0;
        int l=i,r=i+1;
        while(l >= 0 && r < len)
        {
            lsum=lsum + str[l]-'0';
            rsum=rsum + str[r]-'0';
            if(lsum==rsum)
            ans=max(ans,r-l+1);
            l--;
            r++;
        }
    }
    return ans;
}

int main() {
	int t;
	cin>>t;
	while(t--)
	{
	    string str;
	    cin>>str;
	   int len=str.length();
	   cout<<fn(str,len) ;
	   cout<<endl;
	}
	return 0;
}
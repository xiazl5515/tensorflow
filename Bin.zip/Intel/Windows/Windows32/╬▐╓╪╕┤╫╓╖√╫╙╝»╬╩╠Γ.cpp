#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int toBits(int n) {
    int mask = 0;
    while (n > 0) {
        mask |= 1 << (n%10);
        n /= 10;
    }
    return mask;
}

int find(int n, int a[]) {
    vector<int> dp(1 << 10, 0);
    for (int i = 0; i < n; i++) {
        for (int j = dp.size()-1; j > -1; j--) {
            auto m = toBits(a[i]);
            if ((m&j) == m) {
                dp[j] = max(dp[j], dp[m^j] + a[i]);
            }
        }
    }
    return *std::max_element(dp.begin(), dp.end());
}

int main() {
	int t;
	cin >> t;
	while (t-- > 0) {
	    int n; cin >> n;
	    int a[n];
	    for (int i = 0; i < n; i++) cin >> a[i];
	    cout << find(n,a) << '\n';
	}
	return 0;
}

#include<iostream>
using namespace std;

struct Node
{
    int start;
    int end;
    int val;
    bool s;
    bool e;
};

int main() {
	int T, n, p, a, b, d;
	Node res[51];
	Node r[50];
	cin >> T;
	for(int icase = 0; icase < T; icase++)
	{
	    for(int i = 1; i < 51; i++)
	    {
	        res[i].start = i;
	        res[i].s = true;
	        res[i].e = true;
	    }
	    cin >> n >> p;
	    for(int iline = 0; iline < p; iline++)
	    {
	        cin >> a >> b >> d;
	        res[a].start = a;
	        res[a].end = b;
	        res[a].val = d;
	        res[a].e = false;
	        res[b].s = false;
	    }
	    int index = 0;
	    for(int i = 1; i <= n; i++)
	    {
	        if(!res[i].s)
	            continue;
	        if(res[i].e)
	            continue;
	        r[index].start = i;
	        Node temp = res[i];
	        int val = res[i].val;
	        while(!temp.e)
	        {
	            if(val > temp.val)
	            {
	                val = temp.val;
	            }
	            temp = res[temp.end];
	        }
	        r[index].end = temp.start;
	        r[index].val = val;
	        index ++;
	    }
	    cout << index << endl;
	    for(int i = 0; i < index; i++)
	    {
	        cout << r[i].start << " " << r[i].end <<" " << r[i].val << endl;
	    }
	}
	return 0;
}
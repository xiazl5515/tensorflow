#include<iostream>
#include<algorithm>
using namespace std;
int compare(const void* aa, const void* bb)
{
    int *a=(int*)aa;
    int *b=(int*)bb;
    if(a[2]==b[2])
    return 0;
    if(a[2]>b[2])
    return -1;
    else 
    return 1;
}
int main()
 {
	int t;
	cin>>t;
	while(t--)
	{
	    int n;
	    cin>>n;
	    int a[n][3];
	    for(int i=0;i<n;i++)
	    cin>>a[i][0]>>a[i][1]>>a[i][2];
	    qsort(a,n,sizeof(a[0]),compare);
	    bool slot[n]={false};
	    int result[n];
	   for (int i=0; i<n; i++)
    {
       
       for (int j=min(n, a[i][1])-1; j>=0; j--)
       {
         
          if (slot[j]==false)
          {
             result[j] = i;  
             slot[j] = true; 
             break;
          }
       }
    }
    int sum=0,count=0;
    for(int i=0;i<n;i++)
    {
    	if(slot[i])
    	{
    		count++;
    		sum+=a[result[i]][2];
    	}
    }
    cout<<count<<" "<<sum<<endl;
	}
	return 0;
}
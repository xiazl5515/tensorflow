#include<iostream>
using namespace std;
int main(){
    int t, n, i, temp, sum;
    cin>>t;
    while(t--){
        cin>>n;
        int arr[51] = {};
        for(i = 0; i < n; i++){
            cin>>temp;
            arr[temp]++;
        }
        i = 50;
        while(arr[i] == 0 && i >= 0) i--;
        sum = 0;
        while(i >= 0){
            if(arr[i] > 0){
                //cout<<i<<" ";
                sum += i;
                arr[i]--;
                arr[i-1]--;
            }
            while(i >= 0 && arr[i] <= 0) i--;
        }
        cout<<sum<<endl;
    }
    return 0;
}

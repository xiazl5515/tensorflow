#include<iostream>
#include <vector>
#include <stack>
using namespace std;


void visit(int n, stack<int>& s, bool v[], int& cnt) {
    s.push(n);
    v[n] = true;
    cnt--;
}

bool isP(const vector<string>& dict) {
    vector<vector<int>> in(26), out(26);
    for (const auto& w : dict) {
        int f = w.front()-'a';
        int l = w.back()-'a';
        out[f].push_back(l);
        in[l].push_back(f);
    }
    
    int src = -1;
    int dst = -1;
    int count = 0;
    for (int i = 0; i < 26; i++) {
        if (in[i].empty() && out[i].empty()) {
            continue;
        }
        
        count++;
        int diff = in[i].size() - out[i].size();
        if (diff != 0) {
            return false;
        }
    }
    
    src = 0;
    while (out[src].empty()) {
        src++;
    }
    
    bool v[26] = {0};
    stack<int> st;
    
    visit(src, st, v, count);
    while (!st.empty()) {
        int n = st.top(); st.pop();
        if (out[n].empty()) {
            continue;
        }
        
        for (const int x : out[n]) {
            if (v[x]) {
                continue;
            }
            visit(x, st, v, count);
        }
    }
    return count == 0;
}

int main() {
	int t;
	cin >> t;
	while (t-- > 0) {
	    int n; cin >> n;
	    vector<string> dict(n);
	    for (int i = 0; i < n; i++) {
	        cin >> dict[i];
	    }
	    cout << isP(dict) << '\n';
	}
	return 0;
}

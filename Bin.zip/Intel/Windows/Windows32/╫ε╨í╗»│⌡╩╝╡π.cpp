#include<iostream>
using namespace std;
int main(){
     int t;
     cin>>t;
     while(t--)
     {
         int n,m;
         cin>>n>>m;
         int **a;
         a=new int*[n];
         for(int i=0;i<n;i++)
         a[i]=new int[m];
         for(int i=0;i<n;i++)
         for(int j=0;j<m;j++)
         cin>>a[i][j];
         int **dp;
         dp=new int*[n];
         for(int i=0;i<n;i++)
         dp[i]=new int[m];
         int d;
         if(a[n-1][m-1]<=0)
         d=(a[n-1][m-1]*-1)+1;
         else
         d=1;
         dp[n-1][m-1]=d;
         for(int i=n-2;i>=0;i--)
         {
             if(a[i][m-1]>=dp[i+1][m-1])
             d=1;
             else
             d=dp[i+1][m-1]-a[i][m-1];
             dp[i][m-1]=d;
         }
         for(int j=m-2;j>=0;j--)
         {
             if(a[n-1][j]>=dp[n-1][j+1])
             d=1;
             else
             d=dp[n-1][j+1]-a[n-1][j];
             dp[n-1][j]=d;
         }
         for(int i=n-2;i>=0;i--)
         {
             for(int j=m-2;j>=0;j--)
             {
                 int k=min(dp[i+1][j],dp[i][j+1]);
                 if((a[i][j]>=k))
                 d=1;
                 else
                 d=k-a[i][j];
                 dp[i][j]=d;
             }
         }
         cout<<dp[0][0]<<"\n";
     }
	return 0;
}
#include<iostream>
#include<algorithm>
using namespace std;
int countMinCoins(int N, int A[], int X) {
    const int MAX = std::numeric_limits<int>::max();
    
    int DP[X+1];
    DP[0] = 0;
    for (int i = 1; i <= X; i++) DP[i] = MAX;
    
    for (int i = 0; i < N; i++) {
        int c = A[i];
        for (int j = c; j <= X; j++) {
            if (DP[j-c] != MAX) {
                DP[j] = std::min(DP[j-c]+1, DP[j]);
            }
        }
    }
    return (DP[X] == MAX) ? -1 : DP[X];
}

int main() {
	int T;
	scanf("%d", &T);
	while (T-- > 0) {
	    int N, X;
	    scanf("%d %d", &N, &X);
	    
	    int A[N];
	    for (int i = 0; i < N; i++) scanf("%d", &A[i]);
	    
	    printf("%d\n", countMinCoins(N,A,X));
	}
	return 0;
}
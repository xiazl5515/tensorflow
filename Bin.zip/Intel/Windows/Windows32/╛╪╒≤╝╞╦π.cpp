#include<iostream>
using namespace std;
bool arr[7]={
    1,0,1,0,0,1,1
};
int fun(int i,int j){
    int x=(i*j)%7;
    int c=x;
    x*=x;
    x*=c;
    x=x%7;
    return arr[x];
}
int main() {
	int t;
	cin>>t;
	int dp[1001];
	dp[0]=0;

    for(int i=1;i<1000;i++){
        dp[i]=0;
        for(int j=1;j<=i;j++){
            if(i!=j){
                dp[i]+=fun(i,j);
                dp[i]+=fun(j,i);
            }
            else {
                dp[i]+=fun(i,i);
                
            }
        }
        dp[i]+=dp[i-1];
    }
	while(t--){
	    int n;
	    cin>>n;
       cout<<dp[n]<<endl;
	}
	return 0;
}
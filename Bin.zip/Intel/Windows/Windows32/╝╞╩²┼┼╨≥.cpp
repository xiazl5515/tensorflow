#include <iostream>
#include<vector>
using namespace std;
int main()
{
	while (!cin.eof()) {
		int n;
		cin >> n;
		vector<int> lst(n);
		vector<int> lstc;
		vector<int> lstf(n);
		int max = -1;
		for (int j = 0; j < n; j++) {
			int temp;
			cin >> temp;	
			if (temp > max)max = temp;
			lstc.resize(max+1);
			lst[j] = temp;
			lstc[lst[j]]++;
		}
		for (int i = 1; i < lstc.size(); i++) {
			lstc[i] += lstc[i - 1];
		}
		for (int i = n-1; i >=0; i--) {
			lstf[--lstc[lst[i]]] = lst[i];
		}
		for (int i = 0; i < n - 1; i++) {
			cout << lstf[i] << " ";
		}
		cout << lstf[n - 1] << endl;
	}
	return 0;
}
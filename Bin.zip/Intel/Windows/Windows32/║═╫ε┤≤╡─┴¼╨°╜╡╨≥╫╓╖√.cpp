#include<string>
#include<iostream>
using namespace std;

int main() {
    int t;
    cin>>t;
    while(t--)
    {
         string s;
         cin>>s;
         int arr[26]={ 0 };
         for(int i=0;i<s.length();i++)
         {
            arr[s[i]-'A']=1;
         }
         string res="";
    for(int j=1;j<26;j++)
         {
         for(int i=25;i>=0;i--)
         {
             if(arr[i]!=0)
             {
                     string ss="";
                     ss=ss+(char)('A'+i);
                     for(int k=i-j;k>=0;k-=j)
                     {
                        if(arr[k]!=0)
                        {
                            ss=ss+(char)('A'+k);
                        }
                        else
                        {
                            break;
                        }
                     }
                    
                     if(ss.length()>res.length())
                        res=ss;
                 }
             }                 
         }
         cout<<res<<endl;
    }
    return 0;
}
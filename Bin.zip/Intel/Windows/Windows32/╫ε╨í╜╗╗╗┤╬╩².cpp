#include<iostream>
#include<algorithm>
#include<string.h>
using namespace std;

int minSwaps(int arr[], int n){

    pair<int,int> arrPos[n];
    for(int i=0;i<n;i++){
        arrPos[i].first=arr[i];
        arrPos[i].second=i;
    }
    int ans=0;
    
    sort(arrPos,arrPos+n);
    bool* vis=new bool[n];memset(vis,0,n);
    for(int i=0;i<n;i++){
        if(vis[i]|| arrPos[i].second==i)continue;
        int j=i;
        int cyclesize=0;
        while(!vis[j]){
            vis[j]=true;
            j=arrPos[j].second;
            cyclesize++;
        }
        ans+=(cyclesize-1);
    }
    return ans;
}
int main(){
    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        int temp[n];
        for(int i=0;i<n;i++){
            int in;
            cin>>in;
            temp[i]=in;
        }
        cout<<minSwaps(temp,n)<<endl;
    }
}
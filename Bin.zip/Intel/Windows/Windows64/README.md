# Fuck-NJU-OJ

## TOFUCK:

- [ ] KD树构造和查找（已有cpp实现）
